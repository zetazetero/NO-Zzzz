NO Zzzzzz - Proyecto Android Studio

Abre esta carpeta en Android Studio, sincroniza Gradle y usa Build > Build APK(s).
Requiere Android SDK y acceso a dependencias Gradle.
El seguimiento nativo usa servicio en primer plano y alarma del sistema.
La selección de MP3 en el HTML sirve para la prueba en pantalla; NO se integra aún con la alarma nativa en segundo plano.
El mapa y el buscador requieren internet.
Prueba permisos y comportamiento con pantalla bloqueada en un dispositivo real.
