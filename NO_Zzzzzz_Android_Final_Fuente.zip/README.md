# NO Zzzzzz Android
Proyecto para generar un APK debug con GitHub Actions. Sube el CONTENIDO de esta carpeta a la raíz de un repositorio GitHub, abre Actions > Compilar APK NO Zzzzzz > Run workflow y descarga el artefacto NO-Zzzzzz-APK. Se requiere conexión para mapa/búsqueda y servicios Google Play para GPS.

## Limitaciones
No se ha compilado ni probado en un teléfono real. El servicio sigue con pantalla apagada y tras retirar la actividad, pero Android puede finalizarlo por restricciones de batería, revocación de permisos o Forzar detención. Reinicio del teléfono no reanuda automáticamente. Las alarmas nativas se detienen desde la notificación. El selector de archivo HTML no almacena el audio nativo: usa el botón «Elegir audio para alarma Android».
