package com.paradero.alerta

import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import org.json.JSONArray

class TrackingService:Service(){
 private val channel="travel";private val alarmChannel="arrival"
 private lateinit var client:FusedLocationProviderClient
 private var callback:LocationCallback?=null
 private var player:MediaPlayer?=null
 private var vibrator:Vibrator?=null
 private var stops=JSONArray();private var index=0;private var radius=300;private var tone="classic"
 private var ringing=false;private var lastAlarmAt=0L
 private val prefs by lazy{getSharedPreferences("nozz",MODE_PRIVATE)}
 override fun onCreate(){super.onCreate();client=LocationServices.getFusedLocationProviderClient(this)
  val mgr=getSystemService(NotificationManager::class.java)
  mgr.createNotificationChannel(NotificationChannel(channel,"Seguimiento del viaje",NotificationManager.IMPORTANCE_LOW))
  mgr.createNotificationChannel(NotificationChannel(alarmChannel,"Alarma de llegada",NotificationManager.IMPORTANCE_HIGH).apply{enableVibration(true)})
 }
 private fun actionIntent(action:String,code:Int)=PendingIntent.getService(this,code,Intent(this,TrackingService::class.java).apply{this.action=action},PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
 private fun notification(message:String):Notification{
  val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  return Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("NO Zzzzzz · Viaje activo").setContentText(message).setContentIntent(open).setOngoing(true).addAction(android.R.drawable.ic_delete,"STOP",actionIntent("STOP",1)).build()
 }
 private fun persist(){prefs.edit().putString("trip",stops.toString()).putInt("index",index).putInt("radius",radius).putString("tone",tone).putBoolean("active",true).apply()}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  when(intent?.action){
   "STOP"->{prefs.edit().putBoolean("active",false).apply();stopSelf();return START_NOT_STICKY}
   "SILENCE"->{silence();return START_STICKY}
   "TEST"->{tone=intent.getStringExtra("tone")?:"classic";startForeground(10,notification("Prueba de alarma"));ring("Prueba de alarma");return START_NOT_STICKY}
   "START"->{try{stops=JSONArray(intent.getStringExtra("stops")?:"[]")}catch(_:Exception){return START_NOT_STICKY};index=0;radius=intent.getIntExtra("radius",300).coerceIn(50,5000);tone=intent.getStringExtra("tone")?:"classic";silence();persist()}
   else->{if(!prefs.getBoolean("active",false))return START_NOT_STICKY;try{stops=JSONArray(prefs.getString("trip","[]"))}catch(_:Exception){return START_NOT_STICKY};index=prefs.getInt("index",0);radius=prefs.getInt("radius",300);tone=prefs.getString("tone","classic")?:"classic"}
  }
  if(stops.length()==0 || index>=stops.length()){stopSelf();return START_NOT_STICKY}
  startForeground(10,notification("Parada ${index+1} de ${stops.length()} · GPS activo"))
  callback?.let{client.removeLocationUpdates(it)}
  callback=object:LocationCallback(){override fun onLocationResult(result:LocationResult){val loc=result.lastLocation?:return;if(!loc.hasAccuracy()||loc.accuracy>100f)return
   if(index>=stops.length())return
   val stop=stops.optJSONObject(index)?:return
   val dist=FloatArray(1);Location.distanceBetween(loc.latitude,loc.longitude,stop.optDouble("lat"),stop.optDouble("lng"),dist)
   if(dist[0]<=radius && System.currentTimeMillis()-lastAlarmAt>15000){
    lastAlarmAt=System.currentTimeMillis();ring("¡Llegaste a ${stop.optString("name","tu parada")}!")
    index++;if(index<stops.length()){persist();getSystemService(NotificationManager::class.java).notify(10,notification("Siguiente parada ${index+1} de ${stops.length()}"))}
    else{prefs.edit().putBoolean("active",false).apply();client.removeLocationUpdates(this);callback=null}
   }
  }}
  val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,5000L).setMinUpdateIntervalMillis(2000L).build()
  if(ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){try{client.requestLocationUpdates(req,callback!!,mainLooper)}catch(_:SecurityException){stopSelf()}}else stopSelf()
  return START_STICKY
 }
 private fun ring(message:String){silence();ringing=true
  val uri=if(tone=="custom")prefs.getString("audio",null)?.let{android.net.Uri.parse(it)}else null
  val fallback=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?:RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
  try{player=MediaPlayer().apply{setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());setDataSource(this@TrackingService,uri?:fallback);isLooping=true;prepare();start()}}catch(_:Exception){try{player?.release();player=MediaPlayer.create(this,fallback)?.apply{isLooping=true;start()}}catch(_:Exception){}}
  vibrator=getSystemService(VIBRATOR_SERVICE) as Vibrator
  vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0,700,400),0))
  getSystemService(NotificationManager::class.java).notify(11,Notification.Builder(this,alarmChannel).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("NO Zzzzzz · ¡Paradero cerca!").setContentText(message).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Silenciar",actionIntent("SILENCE",2)).addAction(android.R.drawable.ic_delete,"STOP",actionIntent("STOP",1)).build())
 }
 private fun silence(){ringing=false;try{player?.stop()}catch(_:Exception){};player?.release();player=null;vibrator?.cancel();getSystemService(NotificationManager::class.java).cancel(11)}
 override fun onDestroy(){callback?.let{client.removeLocationUpdates(it)};silence();super.onDestroy()}
 override fun onBind(intent:Intent?)=null
}
