package com.paradero.alerta

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
 private lateinit var web: WebView
 private var pendingTrip: Intent? = null
 private val pickAudio = 24
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  web=WebView(this);setContentView(web)
  web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.setGeolocationEnabled(true)
  web.webViewClient=WebViewClient()
  web.webChromeClient=object:WebChromeClient(){override fun onGeolocationPermissionsShowPrompt(origin:String?,callback:GeolocationPermissions.Callback?){callback?.invoke(origin,true,false)}}
  web.addJavascriptInterface(Bridge(),"Android")
  web.loadUrl("file:///android_asset/index.html")
  requestPermissionsIfNeeded()
 }
 private fun requestPermissionsIfNeeded(){
  val list=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
  if(Build.VERSION.SDK_INT>=33)list.add(Manifest.permission.POST_NOTIFICATIONS)
  ActivityCompat.requestPermissions(this,list.toTypedArray(),1)
 }
 private fun launchTrip(i:Intent){
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){pendingTrip=i;requestPermissionsIfNeeded();Toast.makeText(this,"Permite la ubicación para iniciar",Toast.LENGTH_LONG).show();return}
  try{ContextCompat.startForegroundService(this,i)}catch(e:Exception){Toast.makeText(this,"No se pudo iniciar: ${e.message}",Toast.LENGTH_LONG).show()}
 }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==1 && grantResults.any{it==PackageManager.PERMISSION_GRANTED}){pendingTrip?.let{launchTrip(it)};pendingTrip=null}}
 @Deprecated("Deprecated in Java")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==pickAudio && resultCode==RESULT_OK){data?.data?.let{uri->try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};getSharedPreferences("nozz",MODE_PRIVATE).edit().putString("audio",uri.toString()).apply();Toast.makeText(this,"Audio de alarma guardado",Toast.LENGTH_SHORT).show()}}
 }
 inner class Bridge{
  @JavascriptInterface fun startTrip(json:String,radius:Int,tone:String){runOnUiThread{launchTrip(Intent(this@MainActivity,TrackingService::class.java).apply{action="START";putExtra("stops",json);putExtra("radius",radius);putExtra("tone",tone)})}}
  @JavascriptInterface fun stop(){runOnUiThread{startService(Intent(this@MainActivity,TrackingService::class.java).apply{action="STOP"})}}
  @JavascriptInterface fun silence(){runOnUiThread{startService(Intent(this@MainActivity,TrackingService::class.java).apply{action="SILENCE"})}}
  @JavascriptInterface fun testAlarm(tone:String){runOnUiThread{launchTrip(Intent(this@MainActivity,TrackingService::class.java).apply{action="TEST";putExtra("tone",tone)})}}
  @JavascriptInterface fun selectAudio(){runOnUiThread{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},pickAudio)}}
 }
}
