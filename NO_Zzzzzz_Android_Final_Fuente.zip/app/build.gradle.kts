plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.paradero.alerta"; compileSdk = 35
 defaultConfig { applicationId = "com.paradero.alerta"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.1" } }
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("com.google.android.gms:play-services-location:21.3.0") }
